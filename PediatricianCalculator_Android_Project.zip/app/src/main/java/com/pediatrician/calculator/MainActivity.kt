package com.pediatrician.calculator

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlin.math.*

private fun n(s: String): Double = s.toDoubleOrNull() ?: 0.0
private fun fmt(x: Double, d: Int = 2): String = "%.${d}f".format(x).trimEnd('0').trimEnd('.')
private fun round01(x: Double) = round(x * 100.0) / 100.0
private fun round05(x: Double) = round(x * 2.0) / 2.0

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = lightColorScheme(), content = content)
}

@Composable
fun MainActivityScreen() {
    var screen by remember { mutableStateOf("home") }
    AppTheme {
        Surface(Modifier.fillMaxSize()) {
            when (screen) {
                "home" -> Home { screen = it }
                "status" -> StatusEpilepticus { screen = "home" }
                "infusion" -> Infusion { screen = "home" }
                "appendix" -> Appendix { screen = "home" }
                "mg" -> Magnesium { screen = "home" }
                "acidosis" -> Acidosis { screen = "home" }
                "calcium" -> Hypocalcemia { screen = "home" }
                "sodium" -> Hyponatremia { screen = "home" }
                "potassium" -> Hypokalemia { screen = "home" }
                "phosphate" -> Hypophosphatemia { screen = "home" }
                "hyperk" -> Hyperkalemia { screen = "home" }
                "compat" -> Compatibility { screen = "home" }
            }
        }
    }
}

@Composable
fun Header(title: String, back: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            TextButton(onClick = back) { Text("Home") }
        }
    }
}

@Composable
fun NumField(label: String, value: String, onChange: (String) -> Unit, suffix: String = "") {
    OutlinedTextField(
        value = value, onValueChange = { onChange(it.filter { c -> c.isDigit() || c == '.' }) },
        label = { Text(label) }, suffix = { if (suffix.isNotEmpty()) Text(suffix) },
        singleLine = true, modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)
    )
}

@Composable
fun Result(title: String, text: String) {
    Card(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Column(Modifier.padding(14.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(5.dp))
            Text(text)
        }
    }
}

@Composable
fun Warning() {
    Card(Modifier.fillMaxWidth().padding(8.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
        Text(
            "Clinical safety notice: This app is a calculation aid based on the supplied Excel workbook. Verify doses, concentrations, contraindications, preparation, compatibility, monitoring and local PICU protocols before use.",
            Modifier.padding(12.dp)
        )
    }
}

@Composable
fun Page(title: String, back: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Header(title, back)
        LazyColumn(Modifier.fillMaxSize().padding(horizontal = 12.dp), contentPadding = PaddingValues(bottom = 30.dp)) {
            item { Warning() }
            item { Column(content = content) }
        }
    }
}

@Composable
fun Home(go: (String) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), contentPadding = PaddingValues(bottom = 30.dp)) {
        item {
            Text("Pediatrician Calculator", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("Version 1.1 • Android conversion of the supplied workbook", Modifier.padding(bottom = 12.dp))
            Warning()
            Spacer(Modifier.height(8.dp))
        }
        val items = listOf(
            "status" to "Status Epilepticus",
            "infusion" to "PICU Infusion Rate Calculator",
            "appendix" to "BSA • BMI • GIR • eGFR",
            "mg" to "Magnesium Sulfate",
            "acidosis" to "Metabolic Acidosis Correction",
            "calcium" to "Hypocalcemia Correction",
            "sodium" to "Hyponatremia Correction",
            "potassium" to "Hypokalemia Correction",
            "phosphate" to "Hypophosphatemia Correction",
            "hyperk" to "Hyperkalemia Management",
            "compat" to "Medication / Solution Compatibility"
        )
        items(items) { (route, label) ->
            Button(onClick = { go(route) }, Modifier.fillMaxWidth().padding(vertical = 4.dp)) { Text(label) }
        }
        item {
            Spacer(Modifier.height(12.dp))
            Text("Source workbook modules preserved where practical. Review against your current institutional references before clinical deployment.", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun StatusEpilepticus(back: () -> Unit) {
    var w by remember { mutableStateOf("15") }
    val kg = n(w)
    Page("Status Epilepticus", back) {
        NumField("Weight", w, { w = it }, "kg")
        Result("IV benzodiazepines",
            "Midazolam: ${fmt(min(.15*kg,10.0))} mg IV over 2 min\n" +
            "Lorazepam: ${fmt(min(.1*kg,4.0))} mg IV over 2 min\n" +
            "Diazepam: ${fmt(min(.2*kg,10.0))} mg IV over 2 min")
        Result("If IV access not achieved within 3 minutes",
            "Midazolam buccal: ${fmt(min(.2*kg,10.0))} mg\n" +
            "Midazolam intranasal: ${fmt(min(.2*kg,10.0))} mg, divided between nares\n" +
            "Diazepam rectal age 2–5 y: ${fmt(min(.5*kg,20.0))} mg\n" +
            "Age 6–11 y: ${fmt(min(.3*kg,20.0))} mg\n" +
            "Age ≥12 y: ${fmt(min(.2*kg,20.0))} mg")
        Result("Second-line options",
            "Phenobarbital: ${fmt(15*kg)}–${fmt(20*kg)} mg, max 1000 mg/dose; may repeat every 15 min; max total 40 mg/kg.\n" +
            "Levetiracetam: neonates ${fmt(min(30*kg,4500.0))} mg; older patients ${fmt(min(60*kg,4500.0))} mg.\n" +
            "Valproic acid: ${fmt(min(40*kg,3000.0))} mg; second dose if needed: ${fmt(min(20*kg,3000.0))} mg.\n" +
            "Phenytoin: ${fmt(min(20*kg,1500.0))} mg.\n" +
            "Fosphenytoin: ${fmt(min(20*kg,1500.0))} mg PE.")
    }
}

data class Drug(val name:String, val concentration:Double, val dose:Double, val mode:String, val unit:String)

@Composable
fun Infusion(back: () -> Unit) {
    var w by remember { mutableStateOf("10") }
    val drugs = listOf(
        Drug("Alprostadil",20,.2,"min","mcg/kg/min"),
        Drug("Aminophylline",5,1.0,"hour","mg/kg/hr"),
        Drug("Atracurium",5,10.0,"min","mcg/kg/min"),
        Drug("Calcium Gluconate",100,8.0,"hour","mg/kg/hr"),
        Drug("Dexmedetomidine",4,.3,"hour","mcg/kg/hr"),
        Drug("Dobutamine",4000,2.0,"min","mcg/kg/min"),
        Drug("Dopamine",3.2,2.0,"min","mg/kg/min"),
        Drug("Epinephrine",50,.1,"min","mcg/kg/min"),
        Drug("Fentanyl",25,2.0,"hour","mcg/kg/hr"),
        Drug("Furosemide",5,.1,"hour","mg/kg/hr"),
        Drug("Fat Emulsion 20% Undiluted",.2,.25,"min","mL/kg/min"),
        Drug("Isoproterenol",64,.1,"min","mcg/kg/min"),
        Drug("Ketamine",2,5.0,"min","mcg/kg/min"),
        Drug("Labetalol",2,.25,"hour","mg/kg/hr"),
        Drug("Magnesium Sulfate",50,25.0,"hour","mg/kg/hr"),
        Drug("Midazolam",1000,2.0,"min","mcg/kg/min"),
        Drug("Milrinone",200,.25,"min","mcg/kg/min"),
        Drug("Nitroprusside",200,.3,"min","mcg/kg/min"),
        Drug("Norepinephrine",64,.1,"min","mcg/kg/min"),
        Drug("Octreotide",10,2.0,"hour","mcg/kg/hr"),
        Drug("Phenobarbital",10,.5,"hour","mg/kg/hr"),
        Drug("Propofol",10,2.0,"hour","mg/kg/hr"),
        Drug("Rocuronium",5,7.0,"min","mcg/kg/min"),
        Drug("Thiopental",25,2.0,"hour","mg/kg/hr")
    )
    Page("PICU Infusion Rate", back) {
        NumField("Patient weight", w, {w=it}, "kg")
        drugs.forEach { d ->
            val rate = when {
                d.unit.contains("mcg/kg/min") -> d.dose* n(w)*60.0 / (if (d.unit.startsWith("mcg")) d.concentration else d.concentration*1000.0)
                d.unit.contains("mg/kg/min") -> d.dose*n(w)*60.0/d.concentration
                d.unit.contains("mL/kg/min") -> d.dose*n(w)*60.0
                else -> d.dose*n(w)/d.concentration
            }
            Result(d.name, "Default concentration ${fmt(d.concentration)}; default dose ${fmt(d.dose)} ${d.unit}; calculated rate: ${fmt(round01(rate))} mL/hour")
        }
    }
}

@Composable
fun Appendix(back: () -> Unit) {
    var w by remember { mutableStateOf("15") }
    var h by remember { mutableStateOf("105") }
    var cr by remember { mutableStateOf("56") }
    var len by remember { mutableStateOf("35") }
    var fluid1 by remember { mutableStateOf("1.8") }
    var dex1 by remember { mutableStateOf("10") }
    Page("BSA • BMI • GIR • eGFR", back) {
        NumField("Weight",w,{w=it},"kg")
        NumField("Height",h,{h=it},"cm")
        val kg=n(w); val cm=n(h)
        Result("BSA", "${fmt(round(sqrt((kg*cm)/3600.0)*100)/100)} m²")
        Result("BMI", "${fmt(round(kg/(cm/100).pow(2)*10)/10)} kg/m²")
        NumField("Length/height for eGFR",len,{len=it},"cm")
        NumField("Serum creatinine",cr,{cr=it},"µmol/L")
        val e = 36.5*(n(len)/n(cr))
        Result("Revised Schwartz eGFR", "${fmt(e,3)} mL/min/1.73m² (child/adolescent coefficient)")
        NumField("Fluid 1 rate",fluid1,{fluid1=it},"mL/hr")
        NumField("Dextrose content",dex1,{dex1=it},"g/dL")
        val gir = (n(dex1)*n(fluid1)*10)/(kg*60)
        Result("GIR contribution", "${fmt(gir)} mg/kg/min")
        Text("For full GIR, enter all fluid/feeding sources and include unused sources as 0.", style=MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun Magnesium(back: () -> Unit) {
    var w by remember { mutableStateOf("15") }
    var dose by remember { mutableStateOf("50") }
    Page("Magnesium Sulfate",back) {
        NumField("Weight",w,{w=it},"kg")
        NumField("Dose",dose,{dose=it},"mg/kg/dose")
        val mg=min(n(w)*n(dose),2000.0)
        Result("Hypomagnesemia", "Neonates: give MgSO₄ ${fmt(mg)} mg diluted in ${fmt(mg/200,1)} mL; infusion volume basis from workbook.\nOlder patients: give MgSO₄ ${fmt(mg)} mg diluted in ${fmt(mg/200,1)} mL.")
        Result("Acute asthma exacerbation", "At 25–75 mg/kg/dose (max 2000 mg): ${fmt(mg)} mg; verify local dilution and infusion protocol.")
    }
}

@Composable
fun Acidosis(back: () -> Unit) {
    var w by remember { mutableStateOf("18") }
    var hco3 by remember { mutableStateOf("13") }
    var bd by remember { mutableStateOf("7") }
    Page("Metabolic Acidosis Correction",back) {
        NumField("Weight",w,{w=it},"kg")
        NumField("HCO₃",hco3,{hco3=it},"mmol/L")
        NumField("Base deficit",bd,{bd=it},"mmol/L")
        val fullH=.5*n(w)*(24-n(hco3)); val fullBD=.3*n(w)*n(bd)
        Result("Half correction", "Based on HCO₃: ${fmt(round05(fullH/2))} mEq\nBased on base deficit: ${fmt(round05(fullBD/2))} mEq")
        Result("Full correction", "Based on HCO₃: ${fmt(round05(fullH))} mEq\nBased on base deficit: ${fmt(round05(fullBD))} mEq")
        Result("Maximum daily dose", "${fmt(n(w)*8)} mEq/day")
    }
}

@Composable
fun Hypocalcemia(back: () -> Unit) {
    var w by remember { mutableStateOf("20") }
    var ca by remember { mutableStateOf("1.4") }
    var alb by remember { mutableStateOf("20") }
    var dose by remember { mutableStateOf("100") }
    Page("Hypocalcemia Correction",back) {
        NumField("Weight",w,{w=it},"kg")
        NumField("Serum calcium",ca,{ca=it},"mmol/L")
        NumField("Albumin",alb,{alb=it},"g/L")
        val corrected=(40-n(alb))*.02+n(ca)
        NumField("IV calcium gluconate dose",dose,{dose=it},"mg/kg/dose")
        val elemental=n(dose)/100*9.3
        Result("Corrected calcium", "${fmt(corrected)} mmol/L")
        Result("Symptomatic hypocalcemia", "Calcium gluconate 1 mL/kg/dose: ${fmt(n(w))} mL (max 20 mL).\n2 mL/kg/dose: ${fmt(min(2*n(w),20.0))} mL.\nCalcium chloride 0.2 mL/kg/dose: ${fmt(min(.2*n(w),10.0))} mL.")
        Result("IV calcium gluconate elemental calcium", "${fmt(elemental)} mg elemental calcium at the selected ${fmt(n(dose))} mg/kg/dose.")
        Text("Crystallization ratio = phosphate / calcium relationship; verify the workbook's local preparation rules and current pharmacy guidance.", style=MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun Hyponatremia(back: () -> Unit) {
    var w by remember { mutableStateOf("15") }
    var dose by remember { mutableStateOf("3") }
    var na by remember { mutableStateOf("117") }
    var desired by remember { mutableStateOf("122") }
    Page("Hypovolemic Hyponatremia Correction",back) {
        NumField("Weight",w,{w=it},"kg")
        NumField("3% NaCl bolus dose",dose,{dose=it},"mL/kg")
        NumField("Serum Na",na,{na=it},"mmol/L")
        NumField("Desired Na",desired,{desired=it},"mmol/L")
        val bolus=min(n(w)*n(dose),150.0)
        val delta=n(desired)-n(na)
        val mmol=n(w)*n(desired)*.6
        Result("Symptomatic hyponatremia", "3% NaCl IV bolus: ${fmt(bolus)} mL over 20 minutes (maximum 150 mL/dose).")
        Result("Unsafe asymptomatic hyponatremia", "Calculated ΔNa: ${fmt(delta)} mmol/L.\nWorkbook estimate: ${fmt(mmol)} mmol (check target range 4–6 mmol/L and local protocol).")
    }
}

@Composable
fun Hypokalemia(back: () -> Unit) {
    var w by remember { mutableStateOf("10") }
    var conc by remember { mutableStateOf("60") }
    Page("Hypokalemia Correction",back) {
        NumField("Weight",w,{w=it},"kg")
        NumField("Desired KCl concentration",conc,{conc=it},"mEq/L")
        val kg=n(w)
        listOf(
            "K 3.5–4.0" to .25,
            "K 3.0–3.5" to .5,
            "K 2.5–3.0" to .75,
            "K <2.5" to 1.0
        ).forEach { (label,dose) ->
            val meq=min(kg*dose,40.0)
            val mlKcl=meq/2
            val dilution=1000/ n(conc)*meq
            Result(label, "Dose ${fmt(meq)} mEq; KCl volume ${fmt(mlKcl)} mL; final dilution ${fmt(dilution)} mL; infuse over ≤1 hour per workbook.")
        }
    }
}

@Composable
fun Hypophosphatemia(back: () -> Unit) {
    var w by remember { mutableStateOf("20") }
    var kconc by remember { mutableStateOf("60") }
    Page("Hypophosphatemia Correction",back) {
        NumField("Weight",w,{w=it},"kg")
        NumField("Chosen K concentration",kconc,{kconc=it},"mEq/L")
        listOf(.16,.20,.30,.40,.50,.60).forEach { dose ->
            val phos=n(w)*dose
            val kpo4ml=phos/3
            val rounded=ceil(kpo4ml*10)/10
            val kcontent=rounded*4.4
            val dilution=ceil((1000/n(kconc)*kcontent))
            Result("${fmt(dose)} mmol/kg", "KPO₄: ${fmt(phos)} mmol phosphate ≈ ${fmt(rounded,1)} mL; K content ${fmt(kcontent)} mEq; dilution ≈ ${fmt(dilution,0)} mL. Workbook: safest over 6 hours for the higher-dose rows; max phosphorus 45 mmol/dose and potassium 66 mEq/dose.")
        }
        Text("NaPO₄ orders use the workbook's concentration-dependent dilution; verify exact preparation with pharmacy/local protocol.", style=MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun Hyperkalemia(back: () -> Unit) {
    var w by remember { mutableStateOf("23") }
    Page("Hyperkalemia Management",back) {
        NumField("Weight",w,{w=it},"kg")
        val kg=n(w)
        Result("Calcium gluconate", "Calcium gluconate ${fmt(min(100*kg,2000.0))} mg = ${fmt(min(9*kg,180.0))} mg elemental calcium = ${fmt(min(kg,20.0))} mL IV bolus over 5 min; workbook allows repeat ×2.")
        Result("NaHCO₃", "${fmt(kg)}–${fmt(2*kg)} mEq mixed 1:1 with D5W IV over 5–10 min; maximum 2 mEq/kg per dose in workbook.")
        val ventolin=when {
            kg < 25 -> "0.5 mL + 3 mL NS nebulized as needed"
            kg <= 50 -> "1 mL + 3 mL NS nebulized as needed"
            else -> "2–4 mL + 3 mL NS nebulized as needed"
        }
        Result("Ventolin / salbutamol", ventolin)
        Result("Furosemide", "${fmt(kg)}–${fmt(2*kg)} mg IV stat; maximum 200 mg.")
        Result("Regular insulin + glucose", "${fmt(.1*kg)} units regular insulin + ${fmt(2*kg)} mL D25 or ${fmt(5*kg)} mL D5W over 30 min.")
        Result("Potassium-binding resins", "Kayexalate: ${fmt(min(kg,15.0))} g PO Q6h or PR Q2h (workbook maximums apply).\nCalcium Resonium: ${fmt(min(kg,15.0))} g PO or PR Q6h; verify route-specific maximum.")
    }
}

@Composable
fun Compatibility(back: () -> Unit) {
    val meds = listOf(
        "Alprostadil","Aminophylline","Atracurium","Calcium Chloride","Calcium Gluconate",
        "Dexmedetomidine","Dobutamine","Dopamine","Epinephrine","Fentanyl","Fosphenytoin",
        "Furosemide","Isoproterenol","Ketamine","Labetalol","Levetiracetam","Magnesium Sulfate",
        "Midazolam","Milrinone","Morphine","Nitroprusside","Norepinephrine","Phenobarbital",
        "Phenytoin","Octreotide","Potassium Chloride","Potassium Phosphate","Propofol",
        "Rocuronium","Sodium Bicarbonate","Thiopental","Valproic Acid"
    )
    Page("Medication / Solution Compatibility",back) {
        Text("Compatibility matrix from the supplied workbook. Use the original institutional/pharmacy reference for the exact compatibility status before administration.", Modifier.padding(8.dp))
        meds.forEach { Result(it, "NS • D5W • D10W • D5NS • D5-½NS • LR — consult the workbook matrix for status (Compatible / Incompatible / Not Tested / Variable).") }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MainActivityScreen() }
    }
}
