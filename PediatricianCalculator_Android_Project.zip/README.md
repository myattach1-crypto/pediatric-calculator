# Pediatrician Calculator — Android project

This project is an Android Studio conversion of the supplied **The Pediatrician Calculator V1.1.xlsx** workbook.

## Included modules
- Status Epilepticus
- PICU Infusion Rate Calculator
- BSA / BMI / GIR / Revised Schwartz eGFR
- Magnesium Sulfate
- Metabolic Acidosis Correction
- Hypocalcemia Correction
- Hyponatremia Correction
- Hypokalemia Correction
- Hypophosphatemia Correction
- Hyperkalemia Management
- Medication / Solution Compatibility

## Build
1. Open this folder in Android Studio.
2. Allow Gradle to download the Android/Compose dependencies.
3. Select the `app` module.
4. Build > Build APK(s).

The current execution environment does not include the Android SDK/Gradle build tools, so an APK cannot be compiled here. The project is prepared as Android Studio source.

## Important clinical note
The app reproduces calculation logic from the supplied workbook where practical. It is not independently clinically validated. Before clinical use, compare every formula, dose, preparation, maximum, compatibility statement and infusion instruction with current institutional protocols, pharmacy guidance and authoritative references.
